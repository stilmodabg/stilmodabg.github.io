JavaScript:

// Agregar evento de clic a cada opción del menú
document.querySelectorAll('nav a').forEach((link) => {
  link.addEventListener('click', (e) => {
    e.preventDefault();
    const target = document.querySelector(link.getAttribute('href'));
    target.style.display = 'block';
  });
});